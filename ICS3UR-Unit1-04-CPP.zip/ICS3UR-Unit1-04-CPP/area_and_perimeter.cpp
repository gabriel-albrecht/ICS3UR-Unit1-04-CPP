// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Nov 2020
// This program calculates the area and perimeter of a 5 by 4 rectangle

#include <iostream>

int main() {
    std::cout << "If a rectangle has the dimensions:" << std::endl;
    std::cout << "5m x 4m" << std::endl;
    std::cout << "" << std::endl;
    std::cout << "Area is " << (5*4) << "m" << std::endl;
    std::cout << "Perimeter is " << (2*(5+4)) << "m" << std::endl;
}
